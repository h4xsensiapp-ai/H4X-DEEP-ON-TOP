<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/inc/bootstrap.php';
header('Content-Type: application/json');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['error'=>'POST required']);exit;}
$b=json_decode(file_get_contents('php://input'),true)?:[];$token=(string)($b['idToken']??'');
if($token===''||strlen($token)>10000){http_response_code(400);echo json_encode(['error'=>'Missing Firebase token']);exit;}
$key=(string)($config['firebase']['api_key']??'');
if($key===''||str_contains($key,'YOUR_')){http_response_code(500);echo json_encode(['error'=>'Configure Firebase API key']);exit;}
$ch=curl_init('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='.rawurlencode($key));
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode(['idToken'=>$token]),CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_TIMEOUT=>12]);
$res=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$data=json_decode((string)$res,true);
if($status!==200||empty($data['users'][0]['localId'])){http_response_code(401);echo json_encode(['error'=>'Firebase token verification failed']);exit;}
$f=$data['users'][0];$uid=(string)$f['localId'];$email=(string)($f['email']??'');$role=is_admin_uid($uid)?'admin':'user';
$q=$pdo->prepare("INSERT INTO users(firebase_uid,email,display_name,role,last_seen_at) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE email=VALUES(email),display_name=VALUES(display_name),role=VALUES(role),last_seen_at=NOW()");
$q->execute([$uid,$email,(string)($f['displayName']??''),$role]);session_regenerate_id(true);
$_SESSION['user']=['uid'=>$uid,'email'=>$email,'name'=>(string)($f['displayName']??''),'role'=>$role];
echo json_encode(['ok'=>true,'redirect'=>$role==='admin'?'admin.php':'user.php']);
