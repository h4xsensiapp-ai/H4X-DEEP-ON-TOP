<?php
declare(strict_types=1);
session_start();
$cp=dirname(__DIR__).'/config.php';
if(!is_file($cp)){http_response_code(500);exit('Missing config.php. Copy config.example.php and configure it.');}
$config=require $cp;
$dsn=sprintf('mysql:host=%s;dbname=%s;charset=%s',$config['db']['host'],$config['db']['name'],$config['db']['charset']??'utf8mb4');
try{$pdo=new PDO($dsn,$config['db']['user'],$config['db']['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);}
catch(Throwable $e){http_response_code(500);exit('Database connection failed. Check config.php and schema import.');}
function h(?string $s):string{return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function csrf_token():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function check_csrf():void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Security token expired. Reload and retry.');}}
function current_user():?array{return $_SESSION['user']??null;}
function require_login():array{$u=current_user();if(!$u){header('Location: login.php');exit;}return $u;}
function require_admin():array{$u=require_login();if(($u['role']??'')!=='admin'){http_response_code(403);exit('Admin access required.');}return $u;}
function redirect(string $url):never{header('Location: '.$url);exit;}
function is_admin_uid(string $uid):bool{global $config;return in_array($uid,$config['admin_uids']??[],true)&&!str_contains($uid,'REPLACE_');}
function page_header(string $title):void{global $config;echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).' · '.h($config['app_name']).'</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="shell"><header class="top"><a class="brand" href="index.php">H4X <span>DEEP</span></a><span class="pill">CLOUD BOT MANAGEMENT</span></header>';}
function page_footer():void{echo '<footer class="footer">H4X DEEP HOSTING · Secure project management</footer></main></body></html>';}
