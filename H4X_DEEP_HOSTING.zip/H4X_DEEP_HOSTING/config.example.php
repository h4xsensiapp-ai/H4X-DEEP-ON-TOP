<?php
declare(strict_types=1);
return [
 'db'=>['host'=>'localhost','name'=>'h4x_deep_hosting','user'=>'DB_USER','pass'=>'DB_PASSWORD','charset'=>'utf8mb4'],
 'firebase'=>['api_key'=>'YOUR_FIREBASE_WEB_API_KEY','project_id'=>'YOUR_FIREBASE_PROJECT_ID'],
 'admin_uids'=>['REPLACE_WITH_YOUR_FIREBASE_ADMIN_UID'],
 'app_name'=>'H4X DEEP HOSTING',
 'max_code_bytes'=>1048576
];
