# H4X DEEP HOSTING
Premium PHP/MySQL + Firebase Authentication starter.

## Setup
1. Upload this folder to PHP 8.1+ hosting with MySQL, PDO MySQL, cURL and HTTPS.
2. Import `database/schema.sql` into MySQL.
3. Copy `config.example.php` to `config.php`, then fill DB credentials, Firebase API key/project ID and trusted admin UID(s).
4. Enable Email/Password in Firebase Authentication. Add your domain to Authorized domains.
5. Copy Firebase web app settings into `assets/firebase-config.js`.
6. If using Firebase Storage for images, publish `firebase-storage.rules`.
7. Visit `setup.php`, check the configuration, then sign in at `login.php`.
8. Create user accounts in Firebase Console. Add trusted administrator Firebase UIDs to `admin_uids`.
9. Remove `setup.php` after setup.

## Included
Separate user/admin dashboards, Firebase login bridge, MySQL projects, full source-code editor/viewer, project images by URL, project moderation, user directory, announcements, CSRF protection, prepared SQL statements and responsive blue-neon UI.

## Important execution limitation
This panel stores and manages source code; it does NOT execute arbitrary uploaded code or run untrusted bots as server processes. Before offering live bot hosting, add a separate isolated runner using containers, strict CPU/memory/time limits, network restrictions, per-user isolation and secret management. Never use eval/exec/shell_exec/system to run user uploads. Do not paste bot tokens into source code.
